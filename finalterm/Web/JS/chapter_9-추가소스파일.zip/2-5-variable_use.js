console.log(52<273);
console.log(52>273);
console.log(10==20);
console.log(10!=20);
console.log("\n");

console.log(true && true);
console.log(true && false);
console.log(false && true);
console.log(false && false);
console.log("\n");

console.log((10<20) && (20<30));
console.log(!true);
console.log(!(10==10));
console.log("\n");

console.log(true || true);
console.log(true || false);
console.log(false || true);
console.log(false || false);